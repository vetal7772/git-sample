package org.javarush.oleksandr.island.view;

public class StatisticMonitor {
    // TODO: Implement statistic monitor here.
}
