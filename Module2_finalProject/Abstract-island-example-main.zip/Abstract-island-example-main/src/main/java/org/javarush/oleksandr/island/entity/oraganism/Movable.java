package org.javarush.oleksandr.island.entity.oraganism;

public interface Movable {
    void move();
}
