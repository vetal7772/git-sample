package org.javarush.oleksandr.island.entity.oraganism.animal.predator;

import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.javarush.oleksandr.island.entity.oraganism.animal.Animal;

@SuperBuilder
@NoArgsConstructor
public abstract class Predator extends Animal {

}
