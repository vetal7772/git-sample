package org.javarush.oleksandr.island.entity.oraganism;

import org.javarush.oleksandr.island.abstraction.interfaces.GameObject;

public interface Organism extends GameObject  {
}
