package org.javarush.oleksandr.island.abstraction.interfaces;

import org.javarush.oleksandr.island.entity.oraganism.Reproducible;

public interface GameObject extends Reproducible {
    void play();
}
